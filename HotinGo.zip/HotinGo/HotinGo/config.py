# Configurations and Globals
config = {
    "DB_PORT": 3306,
    "DB_NAME": "hms",
    "DB_AUTOCOMMIT": True,
    "DB_HOST": "localhost",
}